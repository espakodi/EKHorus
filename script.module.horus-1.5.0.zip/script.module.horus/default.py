# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# EKHorus by RubénSDFA1laberot, based on Horus by Caperucitaferoz and previous work by:
# - Enen92 (https://github.com/enen92)
# - Joian (https://github.com/jonian)
#
# Thanks to those who have collaborated in any way, especially to:
# - @Canna_76
# - @AceStreamMOD (https://t.me/AceStreamMOD)
# - @luisma66 (tester raspberry)
# - logon84 (agradecimientos de RubénSDFA1laberot 
#   por enlaces ass://, lectura desde txt y Pastebin)
#
# This file is part of EKHorus for Kodi
#
# EKHorus for Kodi is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Cambios de este Mod de Horus respecto a la versión original de Caperucitaferoz 1.1.9 (ver los créditos de arriba):
# - Enlaces ass:// (se resuelven por DNS sobre elcano.top y se decodifican en base64/gzip, con listas anidadas).
# - Búsqueda directa por texto en acestreamsearch.net y search-ace.stream.
# - Varias fuentes a la vez separando las direcciones con ; (fusiona y elimina duplicados).
# - Formatos de lista nuevos: pastebin/.txt, elcano y páginas vercel.app / netlify.app.
# - Segundo motor seleccionable.
# - Código QR del enlace acestream:// como carátula del elemento.
# - Listitems con la API moderna getVideoInfoTag y el ID manual admitiendo un hash de 40 caracteres.
#-------------------------------------------------------------------------------

from lib.utils import *
import base64
import gzip
import json

from acestream.engine import Engine
from acestream.stream import Stream

error_flag = False


def plugin_handle():
    """Handle del directorio de Kodi, o -1 si el addon no fue llamado como plugin."""
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


_directorio_cerrado = False

def cerrar_directorio(succeeded=True, update=False, cache=False):
    """Cierra el directorio de Kodi exactamente una vez, si es que hay uno.

    Cuando otro addon nos llama con PlayMedia (asi lo hace StreamNinja), Kodi
    nos da un handle y espera una respuesta: si el script termina sin darla,
    saca un "reproduccion fallida" encima del video que ya se esta abriendo.
    Es facil olvidarse en alguna rama de salida, asi que se centraliza aqui."""
    global _directorio_cerrado

    handle = plugin_handle()
    if handle < 0 or _directorio_cerrado:
        return

    _directorio_cerrado = True
    xbmcplugin.endOfDirectory(handle=handle, succeeded=succeeded,
                              updateListing=update, cacheToDisc=cache)


class OSD(object):
    def __init__(self, stats):
        self.showing = False
        self.window = xbmcgui.Window(12901)
        self.stats = stats

        viewport_w, viewport_h = self._get_skin_resolution() #(1280, 720)
        posX = viewport_w - 305
        posY = 75

        window_w = 300
        window_h = 250
        font_max = 'font13'
        font_min = 'font10'

        # Background
        self.horus_background = xbmcgui.ControlImage(x=posX, y=posY, width=window_w, height=window_h,
                                                     filename=os.path.join(runtime_path, 'resources', 'media' , 'background.png'))
        # icono
        self.horus_icon = xbmcgui.ControlImage(x=posX + 25, y=posY + 15, width=38, height=28,
                                               filename=os.path.join(runtime_path, 'resources', 'media' , 'acestreamlogo.png'))
        # title
        self.horus_title = xbmcgui.ControlLabel(x=posX + 78, y=posY + 13, width=window_w - 10, height=30,
                                                label="Horus", font=font_max, textColor='0xFFEB9E17')
        # sep
        self.horus_sep1 = xbmcgui.ControlImage(x=posX + 5, y=posY + 55, width=window_w - 10, height=1,
                                               filename=os.path.join(runtime_path, 'resources', 'media', 'separator.png'))
        # Stats
        self.horus_status = xbmcgui.ControlLabel(x=posX + 25, y=posY + 80, width=window_w - 10, height=30, font=font_min, label=translate(30009) % '')
        self.horus_speed_down = xbmcgui.ControlLabel(x=posX + 25, y=posY + 100, width=window_w - 10, height=30, font=font_min, label=translate(30010) % 0)
        self.horus_speed_up = xbmcgui.ControlLabel(x=posX + 25, y=posY + 120, width=window_w - 10, height=30, font=font_min, label=translate(30011) % 0)
        self.horus_peers = xbmcgui.ControlLabel(x=posX + 25, y=posY + 140, width=window_w - 10, height=30, font=font_min, label=translate(30012) % 0)
        self.horus_downloaded = xbmcgui.ControlLabel(x=posX + 25, y=posY + 170, width=window_w - 10, height=30, font=font_min, label=translate(30013) % 0)
        self.horus_uploaded = xbmcgui.ControlLabel(x=posX + 25, y=posY + 190, width=window_w - 10, height=30, font=font_min, label=translate(30014) % 0)

        # sep
        self.horus_sep2 = xbmcgui.ControlImage(x=posX + 5, y=posY + window_h - 30, width=window_w - 10, height=1,
                                               filename=os.path.join(runtime_path, 'resources', 'media', 'separator.png'))

    def update(self,**kwargs):
        if self.showing:
            status = {'dl':translate(30007), 'prebuf': translate(30008) %(self.stats.progress) + '%'}
            self.horus_status.setLabel(translate(30009) % status.get(self.stats.status, self.stats.status))
            self.horus_speed_down.setLabel(translate(30010) % self.stats.speed_down)
            self.horus_speed_up.setLabel(translate(30011) % self.stats.speed_up)
            self.horus_peers.setLabel(translate(30012) % self.stats.peers)
            self.horus_downloaded.setLabel(translate(30013) % (self.stats.downloaded // 1048576))
            self.horus_uploaded.setLabel(translate(30014) % (self.stats.uploaded // 1048576))

    def show(self):
        self.window.addControl(self.horus_background)
        self.window.addControl(self.horus_icon)
        self.window.addControl(self.horus_title)
        self.window.addControl(self.horus_sep1)
        self.window.addControl(self.horus_status)
        self.window.addControl(self.horus_speed_down)
        self.window.addControl(self.horus_speed_up)
        self.window.addControl(self.horus_peers)
        self.window.addControl(self.horus_downloaded)
        self.window.addControl(self.horus_uploaded)
        self.window.addControl(self.horus_sep2)
        self.showing = True

    def hide(self):
        self.showing = False
        self.window.removeControl(self.horus_background)
        self.window.removeControl(self.horus_icon)
        self.window.removeControl(self.horus_title)
        self.window.removeControl(self.horus_sep1)
        self.window.removeControl(self.horus_status)
        self.window.removeControl(self.horus_speed_down)
        self.window.removeControl(self.horus_speed_up)
        self.window.removeControl(self.horus_peers)
        self.window.removeControl(self.horus_downloaded)
        self.window.removeControl(self.horus_uploaded)
        self.window.removeControl(self.horus_sep2)

    def _get_skin_resolution(self):
        # Si el skin no declara resolucion (o su xml no se puede leer), se cae
        # al clasico 1280x720: un OSD algo descolocado es mejor que impedir
        # la reproduccion entera, que es lo que pasaba antes.
        try:
            import xml.etree.ElementTree as ET
            skin_path = translatePath("special://skin/")
            tree = ET.parse(os.path.join(skin_path, "addon.xml"))
            try: res = tree.findall("./res")[0]
            except IndexError: res = tree.findall("./extension/res")[0]
            return int(res.attrib["width"]), int(res.attrib["height"])
        except Exception as e:
            logger("_get_skin_resolution: %s" % e, 'error')
            return 1280, 720

    def close(self):
        try:
            self.hide()
        except:
            pass


class MyPlayer(xbmc.Player):
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(MyPlayer, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        logger("MyPlayer init")
        self.total_Time = 0
        self.monitor = xbmc.Monitor()
        xbmc.Player().stop()
        while xbmc.Player().isPlaying() and not self.monitor.abortRequested():
            self.monitor.waitForAbort(1)


    def playStream(self, stream, title='', iconimage='', plot='', init_time=0.0):
        self.AVStarted = False
        self.is_active = True
        self.init_time = float(init_time)
        # Si el video muere antes del primer getTime() valido, current_time
        # se leia sin haberse asignado nunca (AttributeError).
        self.current_time = 0.0
        self.osd = OSD(stream.stats)

        status = 'failed'

        listitem = xbmcgui.ListItem()
        infotag = listitem.getVideoInfoTag()
        # El motor puede no dar ni filename ni id (y quien nos llama, ni title):
        # setTitle(None) lanza TypeError y la reproduccion moria aqui, muda.
        title = title or stream.filename or stream.id or ADDON_NAME
        infotag.setTitle(title)
        if plot:
            infotag.setPlot(plot)
        art = {'icon': iconimage if iconimage else os.path.join(runtime_path, 'resources', 'media', 'icono_aces_horus.png')}
        listitem.setArt(art)

        self.play(stream.playback_url, listitem)
        cerrar_directorio(succeeded=False, update=True)
        xbmc.executebuiltin('Dialog.Close(all,true)')

        show_stat = False
        while self.is_active and not self.monitor.abortRequested():
            try:
                self.current_time = self.getTime()
            except:
                pass
            if get_setting("show_osd"):
                """if show_stat:
                    # update stat
                    self.osd.update()"""

                if not show_stat and xbmc.getCondVisibility('Window.IsActive(videoosd)'):
                    #show windows OSD
                    self.osd.show()
                    stream.connect('stats::updated', self.osd.update)
                    show_stat = True

                elif not xbmc.getCondVisibility('Window.IsActive(videoosd)'):
                    # hide windows OSD
                    if self.osd.showing:
                        self.osd.hide()
                        stream.disconnect('stats::updated')
                    show_stat = False

            self.monitor.waitForAbort(1)

        if self.AVStarted:
            if self.current_time > 180:
                add_historial({'infohash': stream.infohash,
                                'title': title,
                                'icon': iconimage if iconimage else '',
                                'plot': plot})
                if stream.id:
                    set_setting("last_id", stream.id)

            if self.current_time >= 0.9 * self.total_Time:
                status = 'finished'
            else:
                status = 'stopped'

            self.osd.close()
            clear_cache()

        return status

    def onAVStarted(self):
        logger("PLAYBACK AVSTARTED")
        self.AVStarted = True
        self.total_Time = self.getTotalTime()
        if self.init_time:
            self.seekTime(self.init_time)

    def onPlayBackEnded(self):
        logger("PLAYBACK ENDED") # Corte de red o fin del video
        self.is_active = False

    def onPlayBackStopped(self):
        logger("PLAYBACK STOPPED") # Parado por el usuario o no iniciado por http 429
        self.is_active = False

    def onPlayBackError(self):
        logger("PLAYBACK ERROR")
        self.is_active = False

    def onPlayBackStarted(self):
        logger("PLAYBACK STARTED")

    def kill(self):
        logger("Play Kill")
        self.is_active = False


HISTORIAL_MAX = 20

def historial_path():
    return os.path.join(data_path, "historial.json")


def get_historial():
    historial = list()
    settings_path = historial_path()
    if os.path.isfile(settings_path):
        try:
            historial = load_json_file(settings_path)
        except Exception:
            logger("Error load_file", "error")

    return historial if isinstance(historial, list) else list()


def add_historial(contenido):
    # Sin infohash la entrada no se puede volver a reproducir ni borrar:
    # seria una fila zombi en la lista. Mejor no guardarla.
    if not contenido.get('infohash'):
        logger("add_historial: sin infohash, no se guarda", 'error')
        return

    # Si ya estaba, se reinserta arriba: lo ultimo visto va primero.
    historial = [i for i in get_historial() if i.get('infohash') != contenido['infohash']]
    historial.insert(0, contenido)

    try:
        dump_json_file(historial[:HISTORIAL_MAX], historial_path())
    except Exception as e:
        # El historial es accesorio: si no se puede escribir (disco lleno, permisos)
        # se registra, pero no se aborta el final de la reproduccion.
        logger("add_historial: %s" % e, 'error')


def del_historial(infohash=None):
    if infohash:
        historial = [i for i in get_historial() if i.get('infohash') != infohash]
    else:
        historial = list()

    try:
        dump_json_file(historial, historial_path())
    except Exception as e:
        logger("del_historial: %s" % e, 'error')


def cache_candidates():
    """Rutas donde puede estar la cache de Acestream, por plataforma."""
    paths = list()
    install = get_setting("install_acestream")
    install = install if isinstance(install, str) and os.path.isdir(install) else None

    if system_platform == "windows":
        drive = os.getenv("SystemDrive") or "C:"
        paths.append(os.path.join(drive + os.sep, '_acestream_cache_'))
        for var in ("LOCALAPPDATA", "APPDATA", "USERPROFILE"):
            base = os.getenv(var)
            if base:
                paths.append(os.path.join(base, 'ACEStream', 'cache', '.acestream_cache'))

    elif system_platform == "linux":
        home = os.getenv("HOME")
        if home:
            paths.append(os.path.join(home, '.ACEStream', 'cache', '.acestream_cache'))
            paths.append(os.path.join(home, '.ACEStream', '.acestream_cache'))

    else:
        if get_setting("ace_engine") == "org.free.aceserve":
            paths.append('/storage/emulated/0/org.free.aceserve/files/.ACEStream/')
        paths.append('/storage/emulated/0/org.acestream.engine/.ACEStream/.acestream_cache')

    if install:
        paths.append(os.path.join(install, '.acestream_cache'))
        paths.append(os.path.join(install, 'data', '.acestream_cache'))

    paths.append(os.path.join(data_path, '.acestream_cache'))

    return paths


def find_cache_dir(root, max_depth=4):
    """Busca la cache bajo 'root', acotando la profundidad.

    La version anterior hacia os.walk() desde la raiz del disco (C:\\), lo que
    recorria el sistema de ficheros entero al terminar cada reproduccion."""
    if not root or not os.path.isdir(root):
        return None

    root = os.path.abspath(root)
    base_depth = root.rstrip(os.sep).count(os.sep)
    fallback = None

    for dirpath, dirnames, filenames in os.walk(root):
        # Primero se comprueba y luego se poda: al reves, una cache situada
        # justo en el nivel del limite no llegaba a mirarse nunca.
        if re.search(r'\.acestream_cache', dirpath):
            return dirpath
        if dirpath.endswith(os.path.join('.ACEStream', 'cache')):
            fallback = dirpath

        if dirpath.rstrip(os.sep).count(os.sep) - base_depth >= max_depth:
            dirnames[:] = []

    return fallback


def clear_cache():
    try:
        acestream_cachefolder = get_setting("acestream_cachefolder", None)

        if not (acestream_cachefolder and os.path.isdir(acestream_cachefolder)):
            acestream_cachefolder = None

            for candidate in cache_candidates():
                if candidate and os.path.isdir(candidate):
                    acestream_cachefolder = candidate
                    break

        if not acestream_cachefolder:
            # Ultimo recurso: buscar solo bajo la carpeta del motor y la del addon,
            # nunca en todo el disco.
            install = get_setting("install_acestream")
            roots = [install if isinstance(install, str) else None, data_path]
            for r in roots:
                acestream_cachefolder = find_cache_dir(r)
                if acestream_cachefolder:
                    break

        if acestream_cachefolder:
            # Solo se guarda si cambia: set_setting reescribe settings.xml,
            # y esto corre al final de cada reproduccion.
            if acestream_cachefolder != get_setting("acestream_cachefolder"):
                set_setting("acestream_cachefolder", acestream_cachefolder)

            dirnames, filenames = xbmcvfs.listdir(acestream_cachefolder)
            for f in filenames:
                xbmcvfs.delete(os.path.join(acestream_cachefolder, f))
            logger("clear_cache: %s" % acestream_cachefolder)
        else:
            logger("clear_cache: cache no encontrada", "error")

    except Exception as e:
        logger("error clear_cache: %s" % e, "error")


def read_torrent(torrent, headers=None):
    import bencodepy
    import hashlib

    infohash = None

    try:
        if torrent.lower().startswith('http'):
            torrent_file = http_get_bytes(torrent, headers)

        elif os.path.isfile(torrent):
            with open(torrent, "rb") as f:
                torrent_file = f.read()

        else:
            logger("read_torrent: origen no valido %s" % torrent, 'error')
            return None

        metainfo = bencodepy.decode(torrent_file)
        infohash = hashlib.sha1(bencodepy.encode(metainfo[b'info'])).hexdigest()
        logger(infohash)

    except Exception as e:
        logger(e, 'error')

    return infohash


def acestreams(id=None, url=None, infohash=None, title="", iconimage="", plot=""):
    #logger(id)
    global error_flag
    # Higiene: que un error de una invocacion anterior en el mismo proceso
    # no contamine esta (importa si algun dia se activa reuselanguageinvoker).
    error_flag = False
    player = None
    stream = None
    engine = None
    d = None
    cmd_stop_acestream = None
    acestream_executable = None

    #url = 'http://dl.acestream.org/sintel/sintel.torrent'
    #url = 'https://files.grantorrent.nl/torrents/peliculas/Otra-vuelta-de-tuerca-(The-Turning)-(2020).avi53.torrent'
    #infohash = 'eebd63aa0a5edc49b253fc5741e49e32961d0f4f'


    # verificar argumentos
    if infohash:
        url = id = None
    elif url:
        infohash = id = None
    else:
        regex = re.compile(r'[0-9a-f]{40}\Z',re.I)
        if not regex.match(id):
            xbmcgui.Dialog().ok(HEADING, translate(30015))
            return

    if not server.available:
        # Si la instalacion del motor fallo o se cancelo, el ajuste queda
        # vacio (None o False): sin esta normalizacion, os.path.join lanzaba
        # TypeError fuera de todo try. Con ruta vacia se deja el ejecutable a
        # None, que desemboca en el dialogo amable de "no pudimos iniciarlo".
        install_path = get_setting("install_acestream")
        if not isinstance(install_path, str):
            install_path = ''

        # Create an engine instance. El comando va SIEMPRE como lista: si se
        # pasa como cadena, una ruta con espacios (C:\Users\Juan Perez\...) se
        # parte por la mitad al ejecutarla y el motor no arranca jamas.
        if system_platform == "windows":
            if install_path:
                acestream_executable = [os.path.join(install_path, 'ace_engine.exe')]

        elif system_platform == "linux":
            if arquitectura == 'x86':
                if root:
                    # LibreElec x86
                    if install_path:
                        acestream_executable = [os.path.join(install_path, 'acestream_chroot.start')]
                        cmd_stop_acestream = ["pkill", "acestream"]
                else:
                    # Ubuntu, arch Linux, fedora, mint etc
                    if os.path.exists('/snap/acestreamplayer'):
                        acestream_executable = ['snap', 'run', 'acestreamplayer.engine']
                        cmd_stop_acestream = ["pkill", "acestream"]
                    else:
                        xbmcgui.Dialog().ok(HEADING,translate(30027))
                        return

            elif arquitectura == 'arm' and not root:
                try:
                    data = ''
                    with open("/etc/os-release") as f:
                        data = ensure_str(f.read())
                    if install_path and re.search('osmc|openelec|raspios|raspbian', data, re.I):
                        # osmc, openelec, raspios y raspbian
                        acestream_executable = ['sudo', os.path.join(install_path, 'acestream.start')]
                        cmd_stop_acestream = ['sudo', os.path.join(install_path, 'acestream.stop')]
                except: pass

            elif install_path:
                # LibreELEC, coreElec , alexelec, etc...
                acestream_executable = [os.path.join(install_path, 'acestream.start')]
                cmd_stop_acestream = [os.path.join(install_path, 'acestream.stop')]

        elif system_platform == 'android':
            if get_setting("ace_engine") == "org.free.aceserve":
                AndroidActivity = 'StartAndroidActivity("%s","","","acestream://","","","","","crc644baf9324e22bb51e.LinkHandlerActivity")' % get_setting("ace_engine")
            else:
                AndroidActivity = 'StartAndroidActivity("","org.acestream.action.start_content","","acestream:?content_id=launch")'
            if not xbmcgui.Dialog().yesno(HEADING, translate(30041)):
                return
            logger("Abriendo " + AndroidActivity)
            xbmc.executebuiltin(AndroidActivity)

        logger("acestream_executable= %s" % acestream_executable)

        if cmd_stop_acestream:
            set_setting("cmd_stop_acestream", cmd_stop_acestream)

        if acestream_executable and not server.available:
            engine = Engine(acestream_executable)

        elif not acestream_executable and system_platform != 'android':
            logger("plataforma desconocida: %s" % system_platform)
            if not xbmcgui.Dialog().yesno(HEADING, translate(30016), nolabel=translate(30017), yeslabel=translate(30018)):
                return

    try:
        if id and system_platform == 'android' and get_setting("reproductor_externo"):
            if get_setting("ace_engine") == "org.free.aceserve":
                AndroidActivity = 'StartAndroidActivity("","android.intent.action.VIEW","video/mp4","http://%s:%s/ace/getstream?id=%s")' % (get_setting("ip_addr"),get_setting("ace_port"),id)
            else:
                AndroidActivity = 'StartAndroidActivity("","org.acestream.action.start_content","","acestream:?content_id=%s")' % id
            logger("Abriendo " + AndroidActivity)
            xbmc.executebuiltin(AndroidActivity)
            return

        d = xbmcgui.DialogProgress()
        d.create(HEADING, translate(30033))
        timedown = time.time() + get_setting("time_limit")

        if not acestream_executable or system_platform == 'android':
            while not d.iscanceled() and not server.available and time.time() < timedown and error_flag == False:
                seg = int(timedown - time.time())
                progreso = int((seg * 100) / get_setting("time_limit"))
                line1 = translate(30033)
                line2 = translate(30006) % seg
                try:
                    d.update(progreso, line1, line2)
                except:
                    d.update(progreso, '\n'.join([line1, line2]))
                time.sleep(1)

            if not server.available:
                d.close()
                notification_error(translate(30019))
                raise Exception("accion cancelada o timeout")

        elif engine and not server.available:
            # Start engine if the local server is not available
            engine.connect(['error','error::subprocess'], notification_error)
            #engine.connect(['started', 'terminated'], notification_info)
            engine.start()

            # Wait for engine to start. Lo unico que importa es que el motor
            # responda: en OSMC/LibreELEC el .start es un lanzador que arranca
            # el motor y termina, asi que engine.running vuelve a False y con
            # el "or not engine.running" el bucle no salia nunca, agotaba el
            # tiempo y decia "motor no iniciado" con el motor ya funcionando.
            while not d.iscanceled() and not server.available and time.time() < timedown and error_flag == False:
                seg = int(timedown - time.time())
                progreso = int((seg * 100) / get_setting("time_limit"))
                line1 = translate(30033)
                line2 = translate(30006) % seg
                try:
                    d.update(progreso, line1, line2)
                except:
                    d.update(progreso, '\n'.join([line1, line2]))

                time.sleep(1)

            if d.iscanceled() or time.time() >= timedown or error_flag == True: # Tiempo finalizado o cancelado
                if engine.running:
                    engine.stop()
                d.close()
                if time.time() >= timedown:
                    notification_error(translate(30019))
                raise Exception("accion cancelada o timeout")

        hls = False
        if id:
            # Start a stream using an acestream channel ID
            stream = Stream(server, id=id)
        elif url:
            # Start a stream using an url
            hls = True
            stream = Stream(server, url=url)
        else:
            # Start a stream using an acestream infohash
            hls = True
            stream = Stream(server, infohash=infohash)

        stream.connect('error', notification_error)
        stream.connect(['started','stopped'], notification_info)
        stream.start(hls=hls)


        # Wait for stream to start
        timedown = time.time() + get_setting("time_limit")
        while not d.iscanceled() and time.time() < timedown and (not stream.status or stream.status != 'dl') and error_flag == False:
            if stream.status != 'prebuf':
                seg = int(timedown - time.time())
                progreso = int((seg * 100) / get_setting("time_limit"))
            else:
                progreso = stream.stats.progress
                timedown = time.time() + 100

            if not stream.status:
                line1 = translate(30034)
            elif stream.status == 'prebuf':
                line1 = translate(30008) %(progreso) + '%'
            elif stream.status == 'dl':
                line1 = translate(30007)
            else:
                line1 = stream.status

            line2 = translate(30010) % stream.stats.speed_down
            line3 = translate(30012) % stream.stats.peers
            try:
                d.update(progreso, line1, line2, line3)
            except:
                d.update(progreso, '\n'.join([line1, line2, line3]))

            time.sleep(0.25)

        d.close()
        if d.iscanceled() or time.time() >= timedown or error_flag == True:  # Tiempo finalizado o cancelado
            if error_flag:
                raise Exception("error flag")
            else:
                raise Exception("accion cancelada o timeout")

        # Open a media player to play the stream
        player = MyPlayer()
        player.playStream(stream, title, iconimage, plot)

    except Exception as e:
        logger(e, 'error')
        # Sin esto, un error entre create() y el primer close() dejaba el
        # dialogo de progreso plantado en pantalla.
        try:
            if d: d.close()
        except: pass

    try:
        if player:
            player.kill()
    except: pass

    # Solo si el stream llego a arrancar: parar un stream que nunca arranco
    # pedia http://host/None y disparaba una segunda notificacion de error.
    if stream and stream.command_url:
        stream.stop()

    # stop Engine
    if get_setting("stop_acestream", False) or get_setting("linux_id") == 'ubuntu':
        kill_process()


def notification_info(*args,**kwargs):
    transmitter = kwargs['class_name']
    msg = kwargs['event_name']

    logger("%s: %s" %(transmitter, msg))
    #xbmcgui.Dialog().notification('Acestream %s' % transmitter, msg, os.path.join(runtime_path, 'resources', 'media', 'icono_aces_horus.png'))


def notification_error(*args,**kwargs):
    global error_flag
    transmitter = kwargs.get('class_name', ADDON_NAME)
    event = kwargs.get('event_name','')
    # El motor puede emitir un error sin mensaje: no debe reventar aqui.
    msg = str(args[0]) if args and args[0] else translate(30019)
    error_flag = True

    logger("Error in %s: %s" % (transmitter, msg))

    if event != 'error::subprocess':
        xbmcgui.Dialog().notification('Error Acestream %s' % transmitter, msg,
                                      os.path.join(runtime_path, 'resources', 'media', 'error.png'))


def mainmenu():
    itemlist = list()

    itemlist.append(Item(
        label= translate(30021),
        action='open_settings'
    ))

    itemlist.append(Item(
        label= translate(30082),
        action='apk_menu'
    ))

    itemlist.append(Item(
        label= translate(30081),
        action='espakodi_addons'
    ))

    itemlist.append(Item(
        label= translate(30020),
        action='play'
    ))

    itemlist.append(Item(
        label=translate(30038),
        action='search'
    ))

    if get_historial():
        itemlist.append(Item(
            label = translate(30037),
            action = 'historial'
        ))

    # ping() en vez de available(): un sondeo TCP de 2s. Con available(), un
    # ip_addr remoto apagado bloqueaba la apertura del menu 10 segundos.
    if system_platform != 'android' and server.ping():
        itemlist.append(Item(
            label= translate(30036),
            action='kill'
        ))

    return itemlist


# Los APK del menu son de 32 bits a proposito: van dirigidos a Fire TV Stick y TV box,
# donde pasar un fichero al aparato es un engorro. La explicacion esta en la cadena 30075
APK_DOWNLOADS = (
    ('AceStreamEK-32bits_v3.apk',
     'https://archive.org/download/EKStreamingPackTVv2/AceStreamEK-32bits_v3.apk', 30083),
    ('Aceserve-1.5.7-armeabi-v7a.apk',
     'https://archive.org/download/EKStreamingPackTVv2/Aceserve-1.5.7-armeabi-v7a.apk', 30084),
    ('VLC-3.6.5-armeabi-v7a.apk',
     'https://archive.org/download/EKStreamingPackTVv2/VLC-3.6.5-armeabi-v7a.apk', 30085),
    ('EspaKodi-Warp-0.0.2-armeabi-v7a.apk',
     'https://archive.org/download/EKStreamingPackTVv2/EspaKodi-Warp-0.0.2-armeabi-v7a.apk', 30086),
)


def apk_menu():
    itemlist = list()

    for filename, url, label_id in APK_DOWNLOADS:
        itemlist.append(Item(
            label=translate(label_id),
            action='download_apk',
            filename=filename,
            apk_url=url,
            plot=translate(30075),
            isFolder=False
        ))

    itemlist.append(Item(
        label=translate(30074),
        action='apk_info',
        plot=translate(30075),
        isFolder=False
    ))

    return itemlist


# Resolutores DoH: si uno esta bloqueado en la red del usuario, se prueba el siguiente.
DOH_RESOLVERS = [
    "https://dns.google/resolve?name={}&type=TXT",
    "https://cloudflare-dns.com/dns-query?name={}&type=TXT",
]
ASS_MAX_DEPTH = 10

def resolve_txt(name):
    for resolver in DOH_RESOLVERS:
        try:
            data = http_get_text(resolver.format(name), headers={'Accept': 'application/dns-json'})
            response = json.loads(data)
            if response.get("Answer"):
                return response["Answer"]
        except Exception as e:
            logger("resolve_txt %s: %s" % (resolver.split('/')[2], e), 'error')

    return list()


ass_ids = list()
def ass_decoder(ass_id_or_json, depth=0):
    global ass_ids
    itemlist = list()

    if depth > ASS_MAX_DEPTH:
        logger("ass_decoder: demasiados niveles de anidamiento", 'error')
        return itemlist

    try:
        json_data = json.loads(ass_id_or_json)
        is_json = isinstance(json_data, list)
    except Exception:
        is_json = False

    if not is_json:
        # La entrada es un ASS ID, no un json
        if ass_id_or_json in ass_ids:
            return itemlist

        ass_ids.append(ass_id_or_json)
        host = "{}.elcano.top".format(ass_id_or_json.replace("ass://", ""))

        for answer in resolve_txt(host):
            try:
                raw = answer.get("data", "").strip('"')
                if "H4sIAAAAAAAA" in raw:
                    json_data = gzip.decompress(base64.b64decode(raw)).decode("utf-8")
                else:
                    json_data = base64.b64decode(raw).decode("utf-8")

                itemlist = itemlist + ass_decoder(json_data, depth + 1)
            except Exception as e:
                logger("ass_decoder: respuesta TXT no valida: %s" % e, 'error')
    else:
        for jsitem in json_data:
            if not isinstance(jsitem, dict):
                continue

            if "subLinks" in jsitem:
                itemlist = itemlist + ass_decoder(json.dumps(jsitem["subLinks"]), depth + 1)
            elif "ref" in jsitem:
                itemlist = itemlist + ass_decoder(jsitem["ref"], depth + 1)
            elif "url" in jsitem and re.findall('([0-9a-f]{40})', jsitem["url"], re.I):
                chan_name = jsitem.get("name") or jsitem["url"]
                chan_id = re.findall('([0-9a-f]{40})', jsitem["url"], re.I)[0]
                itemlist.append(Item(label=chan_name ,action='play',id=chan_id))
            else:
                logger("ASS decoder: item ignorado: %s" % jsitem)

    return itemlist


def search_text(query):
    """Busca por texto en los buscadores publicos de acestream."""
    itemlist = list()

    try:
        data = http_get_text("https://acestreamsearch.net/en/?q={}".format(urllib_parse.quote_plus(query)))
        data = data.split("list-group\">")[1].split("</ul>")[0]
        data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
        patron = '<a href="(.*?)">(\\w*.*?)<'
        for channel in re.findall(patron, data, re.I):
            itemlist.append(Item(label=channel[1]+ " (acestreamsearch.net)",
                        action='play',
                        id=channel[0].replace("acestream://","")))
    except Exception as e:
        logger("search acestreamsearch.net: %s" % e, 'error')

    try:
        data = json.loads(http_get_text("https://search-ace.stream/search?query={}".format(urllib_parse.quote_plus(query))))
        for entry in data:
            itemlist.append(Item(label=entry["name"] + " (search-ace.stream)",
                        action='play',
                        id=entry["content_id"]))
    except Exception as e:
        logger("search search-ace.stream: %s" % e, 'error')

    return itemlist


def search(url):
    itemlist = list()
    ids = list()

    try:
        if "://" not in url:
            itemlist = search_text(url)
        elif url.startswith("ass://"):
            global ass_ids
            ass_ids = list()
            itemlist = ass_decoder(url)
        else:
            data = http_get_text(url)

            if data:
                if "pastebin" in url or ".txt" in url:
                    data = data.replace("\n\n", "\n") #remove empty lines
                    data = data.replace("acestream://", "") #remove protocol
                    patron = "(?:.*?)======\n(.*)"
                    tmp = re.findall(patron, data, re.DOTALL) #remove text before "========"
                    if len(tmp) > 0:
                        data = tmp[0]
                    data = re.sub(r'(?m)^\===.*\n?', '', data) #remove lines starting with "==="
                    for it in re.findall(r'(.+?)\n([0-9a-f]{40})(?=\n|$)', data, re.DOTALL):
                        if len(it) == 2 and len(it[1]) > 0:
                                    name = it[0].replace("\n","")
                                    id = it[1]
                                    itemlist.append(Item(label=name ,action='play',id=id))
                elif "elcano" in url:
                    data = json.loads(data.split("linksData = ")[1].split(";")[0])
                    for link in data["links"]:
                        if len(link["url"]) >= 40:
                            itemlist.append(Item(label=link["name"] ,action='play',id=link["url"].replace("acestream://","")))
                elif "vercel.app" in url or "netlify.app" in url:
                    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
                    data = data.replace("acestream://","")
                    patron = "<a href=[\'\"]([0-9a-f]{40})[\'\"](?:.*?)>(?: |)(\\w*.*?)(?: |)<"
                    for channel in re.findall(patron, data, re.I):
                        itemlist.append(Item(label=channel[1],
                                action='play',
                                id=channel[0]))
                else:
                    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

                    # 1) Lista estructurada. parse_literal en vez de eval(): antes,
                    #    cualquier lista remota podia ejecutar codigo en el equipo.
                    entries = list()
                    encontrado = re.findall(r'(\[.*?])', data)
                    if encontrado:
                        aux = parse_literal(encontrado[0])
                        entries = aux if isinstance(aux, list) else list()

                    for n, it in enumerate(entries):
                        # Una entrada corrupta no puede tumbar la lista entera:
                        # se descarta esa y se siguen leyendo las demas.
                        try:
                            if not isinstance(it, dict):
                                continue

                            id = it.get("id") or it.get("url") or ''
                            id = re.findall('([0-9a-f]{40})', str(id), re.I)[0]

                            label = it.get("name") or it.get("title") or it.get("label")
                            icon = it.get("icon") or it.get("image") or it.get("thumb")

                            # n+1: la lista se numera desde 1, como el otro
                            # recorrido; antes esta empezaba en "Opcion 0".
                            new_item = Item(label= label if label else translate(30030) % (n + 1, id), action='play', id=id)

                            if icon:
                                new_item.icon = icon

                            itemlist.append(new_item)
                        except Exception:
                            logger("search: entrada ignorada en %s: %s" % (url, it))

                    # 2) Sin lista estructurada utilizable: m3u y, si tampoco, hashes sueltos.
                    if not itemlist:
                        for patron in [r'#EXTINF:-1.*?id="([^"]+)".*?([0-9a-f]{40})', '#EXTINF:-1.*?,(.*?)http.*?([0-9a-f]{40})']:
                            for label, id in re.findall(patron, data):
                                itemlist.append(Item(label=label, action='play', id=id))
                            if itemlist: break

                    if not itemlist:
                        for patron in [r"acestream://([0-9a-f]{40})", r'(?:"|>)([0-9a-f]{40})(?:"|<)']:
                            n = 1
                            for id in re.findall(patron, data, re.I):
                                if id not in ids:
                                    ids.append(id)
                                    itemlist.append(Item(label= translate(30030) % (n,id),
                                                         action='play',
                                                         id= id))
                                    n += 1
                            if itemlist: break

    except Exception as e:
        # Antes esto era 'except: pass': cualquier fallo de red o de formato
        # se presentaba como "no hay enlaces", sin rastro en el log.
        logger("search '%s': %s" % (url, e), 'error')

    return itemlist


def kill_process():
    cmd_stop_acestream = get_setting("cmd_stop_acestream")

    if system_platform == 'windows':
        # subprocess en vez de os.system: os.system abria una consola negra sobre Kodi.
        subprocess.call(['taskkill', '/F', '/IM', 'ace_engine.exe'], **no_window())

    elif cmd_stop_acestream:
        logger("cmd_stop_acestream= %s" % cmd_stop_acestream)
        subprocess.call(cmd_stop_acestream)


    time.sleep(0.75)

    # La version del motor esta cacheada; hay que olvidarla para saber si sigue vivo.
    server.invalidate()

    if not server.available:
        logger("Motor Acestream cerrado")
        xbmcgui.Dialog().notification(HEADING, translate(30035),
                                      os.path.join(runtime_path, 'resources', 'media', 'icono_aces_horus.png'))
        return True
    else:
        logger("Motor Acestream NO cerrado")
        xbmcgui.Dialog().notification(HEADING, translate(30040),
                                      os.path.join(runtime_path, 'resources', 'media', 'error.png'))
        return False


def qr_poster(id):
    """Genera (una sola vez) el PNG del QR de un enlace acestream://.

    Antes se regeneraba en cada pintado del directorio: en una lista de 300
    canales eran 300 escrituras a disco cada vez que se navegaba."""
    poster_url = os.path.join(translatePath('special://temp'), 'ekhorus_qr_%s.png' % id)

    if os.path.isfile(poster_url) and os.path.getsize(poster_url) > 0:
        return poster_url

    try:
        import pyqrcode

        # Se escribe aparte y se renombra: si Kodi mata el proceso a media
        # escritura, un PNG truncado quedaria cacheado como valido para siempre.
        tmp_path = '%s.%s.tmp' % (poster_url, os.getpid())
        pyqrcode.create("acestream://" + id).png(tmp_path, scale=6)
        os.replace(tmp_path, poster_url)

        return poster_url

    except Exception as e:
        logger("qr_poster: %s" % e, 'error')
        return None


def run(item):
    itemlist = list()

    if not item.action:
        logger("Item sin acción")
        return

    logger("Ejecutando " + str(item))
    if item.action == "mainmenu":
        itemlist = mainmenu()

    elif item.action == "kill":
        if kill_process():
            xbmc.executebuiltin('Container.Refresh')

    elif item.action == "historial":
        for it in get_historial():
            itemlist.append(Item(label= it.get('title'),
                                 action='play',
                                 infohash=it.get('infohash'),
                                 icon=it.get('icon'),
                                 plot=it.get('plot'),
                                 hist=1,
                                 ctx_del=it.get('infohash')))

    elif item.action == "del_historial":
        if item.infohash:
            del_historial(item.infohash)
        elif xbmcgui.Dialog().yesno(HEADING, translate(30051)):
            # Vaciar el historial entero no tiene vuelta atras: se confirma.
            del_historial()
        else:
            return

        xbmc.executebuiltin('Container.Refresh')
        return

    elif item.action == "search":
        # Sin busqueda previa el cuadro se abre vacio. Antes venia precargado con
        # acetv.org, un dominio que ya no existe: el usuario le daba a aceptar y
        # se comia un error de red en su primera busqueda.
        url_list = xbmcgui.Dialog().input(translate(30032), get_setting("last_search", ""))
        if url_list:
            itemlist = list()
            tmp_itemlist = list()
            ids = list()
            for url in url_list.split(";"):
                if url:
                    tmp_itemlist.append(Item(label=">>>>>>>>>> Source [{}] <<<<<<<<<<".format(url) ,action='',id=url))
                    tmp_itemlist = tmp_itemlist + search(url)
            for found in tmp_itemlist:
                if found.id not in ids:
                    itemlist.append(found)
                    ids.append(found.id)
            # Hay resultados si algun item es reproducible (los separadores no
            # cuentan; el umbral anterior por longitudes fallaba con ';' final).
            if any(it.action == 'play' for it in itemlist):
                set_setting("last_search", url_list)
            else:
                xbmcgui.Dialog().ok(HEADING,  translate(30031) % url_list)
                itemlist = list()

        if not itemlist:
            # Cancelado o sin resultados: el directorio quedaba a medio abrir
            # (antes incluso se pintaba una lista solo de separadores).
            cerrar_directorio(succeeded=False)
            return

    elif item.action == 'open_settings':
            xbmcaddon.Addon().openSettings()

    elif item.action == 'apk_menu':
        itemlist = apk_menu()

    elif item.action == 'download_apk':
        download_apk(item.filename, item.apk_url)

    elif item.action == 'apk_info':
        xbmcgui.Dialog().ok(HEADING, translate(30075))

    elif item.action == 'espakodi_addons':
        # El import va aqui dentro a proposito: si no entras al menu, el modulo ni se carga
        handle = plugin_handle()
        if handle < 0:
            return

        from lib import espakodi_installer
        espakodi_installer.render_menu(handle)
        # render_menu() pinta los items pero no cierra: el cierre pasa siempre por aqui,
        # que es lo que evita el segundo endOfDirectory() del finally de __main__
        cerrar_directorio(succeeded=True, cache=True)
        return

    elif item.action == 'ek_launch':
        from lib import espakodi_installer
        espakodi_installer.launch_by_id(item.addon_id)

    elif item.action == 'ek_open_repo':
        from lib import espakodi_installer
        espakodi_installer.open_repo_unificado()

    elif item.action == 'ek_open_apk':
        from lib import espakodi_installer
        espakodi_installer.open_apk_latest()

    elif item.action == 'play':
        id = url = infohash = None

        # Solo los items que YA traen enlace (historial, listas) llevan
        # metadatos propios. El item del menu "Reproducir ID" no: su etiqueta
        # es el texto del menu y no debe acabar como titulo del video.
        meta = {'title': '', 'iconimage': '', 'plot': ''}

        if item.id or item.url or item.infohash:
            meta = {'title': item.label or item.title or '',
                    'iconimage': item.icon or '',
                    'plot': item.plot or ''}

        if item.id:
            id =item.id
        elif item.url:
            url=item.url
        elif item.infohash:
            infohash=item.infohash
        else:
            last_id = get_setting("last_id", "a0270364634d9c49279ba61ae3d8467809fb7095")
            input = xbmcgui.Dialog().input(translate(30022), last_id if get_setting("remerber_last_id") else "")
            if re.findall('^(http|magnet)', input, re.I):
                url = input
            elif re.findall('([0-9a-f]{40})', input, re.I):
                id = re.findall('([0-9a-f]{40})', input, re.I)[0]
            elif input:
                xbmcgui.Dialog().ok(HEADING, translate(30031) % input)
                return

        if id:
            acestreams(id=id, **meta)
        elif url and url.lower().endswith('.torrent'):
            infohash = read_torrent(url)
            if infohash:
                acestreams(infohash=infohash, **meta)
        elif url and url.lower().startswith('magnet:'):
            infohash = re.findall('xt=urn:btih:([a-f0-9]+)', url, re.I)
            if infohash:
                acestreams(infohash=infohash[0], **meta)
        elif url:
            acestreams(url=url, **meta)
        elif infohash:
            acestreams(infohash=infohash, **meta)

        #xbmc.executebuiltin('Container.Refresh')

    if not itemlist:
        # Una carpeta vacia (p.ej. el historial recien vaciado, que se repinta
        # con Container.Refresh) hay que cerrarla igual: sin esto Kodi se
        # quedaba mostrando la lista antigua, ya borrada.
        if item.action in ("mainmenu", "historial"):
            cerrar_directorio(succeeded=True)
        return

    handle = plugin_handle()
    if handle < 0:
        return

    # Se leen una sola vez, no una vez por canal.
    icon_default = os.path.join(runtime_path, 'icon.png')
    show_qr = get_setting("show_qr_codes")
    vaciar_url = 'RunPlugin(%s?%s)' % (sys.argv[0], Item(action='del_historial').tourl())

    for entrada in itemlist:
        listitem = xbmcgui.ListItem(entrada.label or entrada.title)
        infotag = listitem.getVideoInfoTag()
        infotag.setTitle(entrada.label or entrada.title)
        infotag.setMediaType('video')
        infotag.setPlot(entrada.plot or entrada.id or entrada.url)

        poster_url = entrada.icon or icon_default
        # Solo los ids reales (hash de 40) llevan QR: los separadores de fuente
        # y los textos de busqueda no son enlaces acestream.
        if show_qr and entrada.id and re.match(r'[0-9a-f]{40}\Z', str(entrada.id), re.I):
            poster_url = qr_poster(entrada.id) or poster_url

        listitem.setArt({'icon': entrada.icon or icon_default, 'poster': poster_url})

        if entrada.hist:
            # "Vaciar" va en TODAS las filas del historial. Si solo se colgara
            # de las que tienen infohash, una fila sin el dejaria al usuario
            # sin forma de vaciarlo desde la interfaz.
            ctx = list()
            if entrada.ctx_del:
                ctx.append((translate(30048), 'RunPlugin(%s?%s)' % (sys.argv[0], Item(action='del_historial', infohash=entrada.ctx_del).tourl())))
            ctx.append((translate(30049), vaciar_url))
            listitem.addContextMenuItems(ctx)

        if entrada.isPlayable:
            listitem.setProperty('IsPlayable', 'true')
            isFolder = False

        elif isinstance(entrada.isFolder, bool):
            isFolder = entrada.isFolder

        elif entrada.action in ["", "kill", "play", "open_settings"]:
            isFolder = False

        else:
            isFolder = True

        xbmcplugin.addDirectoryItem(
            handle=handle,
            url='%s?%s' % (sys.argv[0], entrada.tourl()),
            listitem=listitem,
            isFolder= isFolder,
            totalItems=len(itemlist)
        )

    xbmcplugin.addSortMethod(handle=handle, sortMethod=xbmcplugin.SORT_METHOD_NONE)
    cerrar_directorio(succeeded=True, cache=True)


def llamada_externa(argumentos):
    """Otro addon nos pide reproducir algo (StreamNinja y compania)."""
    logger("Llamada externa: %s" % argumentos)
    action = argumentos.get('action', '').lower()

    if action == 'install_acestream':
        if system_platform in ['linux', 'windows']:
            install_acestream()
        return

    if action != 'play' or not (argumentos.get('id') or argumentos.get('url') or argumentos.get('infohash')):
        return

    # StreamNinja rebota a Horus cuando su motor nativo no reproduce; sin este
    # cortacircuitos el reenvío entra en bucle infinito Horus<->StreamNinja.
    snb_key = 'ekhorus_snb_' + (argumentos.get('id') or argumentos.get('infohash') or argumentos.get('url') or '')
    win = xbmcgui.Window(10000)
    prev = win.getProperty(snb_key)
    bounced = False
    if prev:
        try:
            bounced = (time.time() - float(prev)) < 15
        except ValueError:
            pass

    if get_setting("redirect_streamninja") and xbmc.getCondVisibility('System.HasAddon(plugin.video.streamninja)') and not bounced:
        win.setProperty(snb_key, str(time.time()))
        fwd = {k: v for k, v in argumentos.items() if k != 'action' and v}
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.streamninja/?action=acestream&%s)' % urllib_parse.urlencode(fwd))
        return

    win.clearProperty(snb_key)
    url = argumentos.get('url') or ''

    if url.lower().endswith('.torrent'):
        infohash = read_torrent(url, argumentos.get('headers'))
        if not infohash:
            # Antes esto era un exit(0) mudo: ni aviso, ni log, ni nada.
            notification_error(translate(30031) % url)
            return
        argumentos['infohash'] = infohash
        argumentos['url'] = None

    elif url.lower().startswith('magnet:'):
        infohash = re.findall('xt=urn:btih:([a-f0-9]+)', url, re.I)
        if not infohash:
            notification_error(translate(30031) % url)
            return
        argumentos['infohash'] = infohash[0]
        argumentos['url'] = None

    acestreams(id=argumentos.get('id'),
               url=argumentos.get('url'),
               infohash=argumentos.get('infohash'),
               title=argumentos.get('title'),
               iconimage=argumentos.get('iconimage'),
               plot=argumentos.get('plot'))


if __name__ == '__main__':
    try:
        if system_platform in ['linux', 'windows'] and not get_setting("install_acestream"):
            install_acestream()

        item = None

        # len(): invocado via RunScript (sin argumentos de plugin) esto reventaba
        # con IndexError antes de llegar a ninguna parte.
        if len(sys.argv) > 2 and sys.argv[2]:
            try:
                item = Item().fromurl(sys.argv[2])
            except Exception:
                # No es un item nuestro: es la query de otro addon.
                argumentos = dict()
                for c in sys.argv[2][1:].split('&'):
                    if '=' not in c:
                        continue
                    # split('=', 1): un valor con '=' dentro (base64, urls firmadas)
                    # reventaba el desempaquetado y tumbaba la llamada externa.
                    k, v = c.split('=', 1)
                    argumentos[k] = urllib_parse.unquote_plus(ensure_str(v))

                llamada_externa(argumentos)
        else:
            item = Item(action='mainmenu')

        if item:
            run(item)

    finally:
        # Red de seguridad. Otros addons nos invocan con PlayMedia, y ahi Kodi
        # nos da un handle y espera respuesta: si el script termina sin darla
        # (una salida temprana, una accion desconocida, un error), Kodi saca un
        # "reproduccion fallida" fantasma. cerrar_directorio() no hace nada si
        # no hay handle o si alguna rama ya lo cerro.
        cerrar_directorio(succeeded=False)
