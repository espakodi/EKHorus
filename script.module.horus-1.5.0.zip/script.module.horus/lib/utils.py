# -*- coding: utf-8 -*-

import sys, os ,re
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import ast
import base64
import copy
import json
import subprocess
import time
import urllib.parse as urllib_parse
import urllib.request as urllib_request

from threading import Lock

LOGINFO = xbmc.LOGINFO

try:
    translatePath = xbmcvfs.translatePath
except:
    translatePath = xbmc.translatePath

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
HEADING = "%s (%s)" %(ADDON_NAME,ADDON_VERSION)

runtime_path = translatePath(ADDON.getAddonInfo('Path'))
icon_path = os.path.join(runtime_path, 'icon.png')
data_path = translatePath(ADDON.getAddonInfo('Profile'))
translate = ADDON.getLocalizedString

# Ninguna peticion de red puede quedarse colgada: Kodi se congela con ella.
HTTP_TIMEOUT = 10
# Tope de descarga. Las listas y los .torrent son de KB; cualquier cosa de este
# tamano es un error o un abuso, y leerla entera agotaria la memoria.
HTTP_MAX_BYTES = 16 * 1024 * 1024
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'


def ensure_str(value, encoding='utf-8', errors='replace'):
    if isinstance(value, bytes):
        return value.decode(encoding, errors)
    return str(value)


def ensure_binary(value, encoding='utf-8'):
    if isinstance(value, str):
        return value.encode(encoding)
    return value


def parse_literal(value):
    """Convierte un texto en un objeto Python sin usar eval().

    Acepta JSON y literales de Python (listas, dicts, numeros, cadenas).
    Devuelve None si el texto no es un literal valido."""
    if not isinstance(value, str):
        return value

    try:
        return json.loads(value)
    except Exception:
        pass

    try:
        return ast.literal_eval(value)
    except Exception:
        return None


def parse_headers(headers):
    if not headers:
        return dict()
    if isinstance(headers, dict):
        return headers

    value = parse_literal(headers)
    return value if isinstance(value, dict) else dict()


def http_get_bytes(url, headers=None, timeout=HTTP_TIMEOUT, max_bytes=HTTP_MAX_BYTES):
    headers = dict(parse_headers(headers))
    headers.setdefault('User-Agent', USER_AGENT)

    req = urllib_request.Request(url, data=None, headers=headers)

    with urllib_request.urlopen(req, timeout=timeout) as response:
        # Se lee un byte de mas para distinguir "justo el limite" de "se pasa".
        # Sin tope, una url que devuelva gigabytes agotaria la memoria de Kodi.
        data = response.read(max_bytes + 1)

    if len(data) > max_bytes:
        raise ValueError("respuesta demasiado grande (mas de %s bytes): %s" % (max_bytes, url))

    return data


def http_get_text(url, headers=None, timeout=HTTP_TIMEOUT):
    return ensure_str(http_get_bytes(url, headers, timeout))


class Item(object):
    defaults = {}

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __contains__(self, item):
        return item in self.__dict__

    def __getattribute__(self, item):
        return object.__getattribute__(self, item)

    def __getattr__(self, item):
        if item.startswith("__"):
            return object.__getattribute__(self, item)
        else:
            return self.defaults.get(item, '')

    def __str__(self):
        return '{%s}' % (', '.join(['\'%s\': %s' % (k, repr(self.__dict__[k])) for k in sorted(self.__dict__.keys())]))

    def getart(self):
        if 'fanart' not in self.__dict__:
            self.__dict__['fanart'] = os.path.join(runtime_path,'fanart.jpg')
        if 'icon' not in self.__dict__ and 'poster' not in self.__dict__ and 'thumb' not in self.__dict__:
            self.__dict__['icon'] = icon_path
        return {k:self.__dict__.get(k) for k in ['poster', 'icon', 'fanart', 'thumb'] if k in self.__dict__}

    def tourl(self):
        value = ensure_binary(self.__str__())
        return ensure_str(urllib_parse.quote(base64.b64encode(value)))

    def fromurl(self, url):
        str_item = ensure_str(base64.b64decode(urllib_parse.unquote(url)))
        item = ast.literal_eval(str_item)
        if not isinstance(item, dict):
            raise ValueError("item no valido: %s" % str_item)
        self.__dict__.update(item)
        return self

    def tojson(self, path=""):
        if path:
            open(path, "wb").write(ensure_binary(dump_json(self.__dict__)))
        else:
            return dump_json(self.__dict__)

    def fromjson(self, json_item=None, path=""):
        if path:
            json_item = open(path, "rb").read()

        if isinstance(json_item, (str, bytes)):
            item = load_json(ensure_str(json_item))
        else:
            item = json_item
        self.__dict__.update(item)
        return self

    def clone(self, **kwargs):
        newitem = copy.deepcopy(self)
        for k, v in kwargs.items():
            setattr(newitem, k, v)
        return newitem


def logger(message, level=None):
    def format_message(data=""):
        try:
            value = str(data)
        except Exception:
            value = repr(data)

        return ensure_str(value)

    texto = '[%s] %s' % (ADDON.getAddonInfo('id'), format_message(message))

    try:
        if level == 'error':
            xbmc.log("######## ERROR #########", xbmc.LOGERROR)
            xbmc.log(texto, xbmc.LOGERROR)
        else:
            xbmc.log(texto, LOGINFO)
    except:
        xbmc.log(str([texto]), LOGINFO)


locker = Lock()
def load_json_file(path):
    with locker:
        data = open(path, 'rb').read()

    data = load_json(ensure_str(data))
    return data


def dump_json_file(data, path):
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path))

    texto = dump_json(data)

    # dump_json() devuelve '' cuando no consigue serializar. Escribir eso
    # borraria el contenido anterior: mejor fallar y dejar el fichero como estaba.
    if not texto:
        raise ValueError("contenido no serializable; no se sobrescribe %s" % path)

    # Escritura atomica: si Kodi se cierra a media escritura, el fichero
    # original sigue intacto en vez de quedar truncado.
    tmp_path = '%s.%s.tmp' % (path, os.getpid())
    with locker:
        try:
            with open(tmp_path, 'wb') as f:
                f.write(ensure_binary(texto))
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, path)
        except Exception:
            if os.path.exists(tmp_path):
                try: os.remove(tmp_path)
                except OSError: pass
            raise


def load_json(*args, **kwargs):
    if "object_hook" not in kwargs:
        kwargs["object_hook"] = set_encoding

    try:
        value = json.loads(*args, **kwargs)
    except Exception:
        value = {}

    return value


def dump_json(*args, **kwargs):
    if not kwargs:
        kwargs = {
            'indent': 4,
            'skipkeys': True,
            'sort_keys': True,
            'ensure_ascii': False
        }

    try:
        value = json.dumps(*args, **kwargs)
    except Exception:
        value = ''

    return value


def set_encoding(dct):
    if isinstance(dct, dict):
        return dict((set_encoding(key), set_encoding(value)) for key, value in dct.items())
    elif isinstance(dct, list):
        return [set_encoding(element) for element in dct]
    elif isinstance(dct, (str, bytes)):
        return ensure_str(dct)
    else:
        return dct


def get_setting(name, default=None):
    value = ADDON.getSetting(name)

    if not value:
        return default
    elif value == 'true':
        return True
    elif value == 'false':
        return False

    try:
        return int(value)
    except ValueError:
        pass

    parsed = parse_literal(value)
    if isinstance(parsed, (list, dict)):
        return parsed

    return value


def set_setting(name, value):
    try:
        if isinstance(value, bool):
            value = "true" if value else "false"
        elif isinstance(value, (int, list)):
            value = str(value)
        elif not isinstance(value, str):
            value = dump_json(value)

        ADDON.setSetting(name, value)

    except Exception as ex:
        logger("Error al convertir '%s' no se guarda el valor \n%s" % (name, ex), 'error')
        return None

    return value


def get_system_platform():
    plataforma = arquitectura = linux_id = "unknown"
    root = True

    if 'ANDROID_STORAGE' in os.environ:
        plataforma = "android"

    elif xbmc.getCondVisibility('system.platform.linux.raspberrypi') or xbmc.getCondVisibility('system.platform.linux'):
        plataforma = "linux"
        if "arm" in os.uname()[4]:
            arquitectura = "arm"
        elif "aarch" in os.uname()[4]:
            arquitectura = "aarch"
        elif "x86" in os.uname()[4]:
            arquitectura = "x86"

        try:
            with open("/etc/os-release", 'rb') as f:
                data = ensure_str(f.read())
                linux_id = re.findall(r"""\bid\s?=\s?["']?(\w+)""", data, re.I)[0]
                set_setting("linux_id", linux_id)
        except:pass

        if os.geteuid() == 0:
            root = True
        else:
            root = False
            if arquitectura == "arm":
                if linux_id not in ['osmc','openelec','raspbian','raspios']:
                    plataforma = str(os.uname())
            elif arquitectura != "x86":
                plataforma = str(os.uname())

    elif xbmc.getCondVisibility('system.platform.windows'):
        plataforma = "windows"

    elif xbmc.getCondVisibility('system.platform.tvos'):  # Supported only on Kodi 19.x
        plataforma = "android" #"tvos"

    return (plataforma, arquitectura, root)


def no_window():
    """Evita que taskkill/subprocess abran una consola negra encima de Kodi."""
    kwargs = {'stdout': subprocess.DEVNULL, 'stderr': subprocess.DEVNULL}

    if hasattr(subprocess, 'STARTUPINFO'):
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        kwargs['startupinfo'] = startupinfo
        kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

    return kwargs


class DownloadCanceled(Exception):
    pass


# Carpetas de Android donde un gestor de archivos puede leer el APK
APK_FOLDER_CANDIDATES = (
    '/storage/emulated/0/Download/',
    '/storage/self/primary/Download/',
    '/sdcard/Download/',
)

APK_DOWNLOAD_TIMEOUT = 30
APK_CHUNK_SIZE = 128 * 1024
PM_INSTALL_TIMEOUT = 180


def translate_fmt(string_id, *args):
    # Si la cadena no esta cargada, translate() devuelve ''. Pasa cuando editas
    # strings.po y no reinicias Kodi, o con un idioma incompleto. Formatear ''
    # con argumentos lanza TypeError, asi que mejor sacar los datos pelados
    # que reventar
    text = translate(string_id) or ''

    if not args:
        return text

    try:
        return text % args
    except TypeError:
        logger("Cadena %s sin cargar o con placeholders erroneos" % string_id, 'error')
        return '\n'.join([text] + [str(a) for a in args]).strip()


def format_size(size):
    size = float(size)
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024.0:
            return "%.1f %s" % (size, unit)
        size /= 1024.0
    return "%.1f TB" % size


def join_path(folder, filename):
    # En Windows os.path.join mete '\' y rompe las rutas VFS tipo smb://
    if "://" in folder:
        return folder.rstrip('/') + '/' + filename
    return os.path.join(folder, filename)


def apk_looks_valid(path):
    # Un APK no deja de ser un ZIP. Si esta cortado le falta el indice del final y se
    # nota sin tocar la red. Pilla lo que el tamano no pilla, como los servidores que
    # no mandan Content-Length o los ficheros a medias de versiones viejas.
    # Devuelve True o False, y None cuando no hay forma de saberlo, como en smb://
    if "://" in path:
        return None

    try:
        import zipfile
        return zipfile.is_zipfile(path)
    except Exception as ex:
        logger("No se pudo validar el APK %s: %s" % (path, ex))
        return None


def default_apk_folder():
    last = get_setting("last_apk_folder", "")
    if isinstance(last, str) and last and xbmcvfs.exists(last):
        return last

    if system_platform == 'android':
        for folder in APK_FOLDER_CANDIDATES:
            if xbmcvfs.exists(folder):
                return folder

    return ""


def download_to(url, dest, dp=None, message=""):
    request = urllib_request.Request(url, headers={'User-Agent': USER_AGENT})
    response = urllib_request.urlopen(request, timeout=APK_DOWNLOAD_TIMEOUT)
    downloaded = 0

    try:
        total = response.headers.get('Content-Length')
        total = int(total) if total and total.isdigit() else 0

        handle = xbmcvfs.File(dest, 'w')
        try:
            while True:
                if dp and dp.iscanceled():
                    raise DownloadCanceled()

                chunk = response.read(APK_CHUNK_SIZE)
                if not chunk:
                    break

                # write() no lanza excepcion, devuelve False. Si no lo miras, un disco
                # lleno te da una descarga "correcta" con un APK cortado dentro
                if not handle.write(bytearray(chunk)):
                    raise IOError(translate(30072) or "Error al escribir en el disco")

                downloaded += len(chunk)

                if dp:
                    if total:
                        dp.update(min(int(downloaded * 100 / total), 100),
                                  "%s\n%s / %s" % (message, format_size(downloaded), format_size(total)))
                    else:
                        dp.update(0, "%s\n%s" % (message, format_size(downloaded)))
        finally:
            handle.close()
    finally:
        response.close()

    # downloaded son los bytes que han llegado de la red, no los que se han escrito.
    # Antes de dar esto por bueno hay que mirar el tamano real del fichero
    written = xbmcvfs.Stat(dest).st_size()
    if total and written < total:
        raise IOError("Descarga incompleta (%s de %s)" % (format_size(written), format_size(total)))

    return written


def kodi_major_version():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except Exception:
        return 0


def apk_autoinstall_supported():
    # Solo Kodi 22+ sobre Android convierte file:// en content:// con el FileProvider.
    # De Kodi 21 para abajo el intent no instala nada y encima puede cerrar Kodi,
    # asi que ni lo intentamos y tiramos de instrucciones manuales
    return system_platform == 'android' and kodi_major_version() >= 22


def folder_is_writable(folder):
    # Mejor enterarse ahora que despues de tragarse 100 MB
    probe = join_path(folder, '.ekhorus_write_test')
    written = False
    try:
        handle = xbmcvfs.File(probe, 'w')
        try:
            written = bool(handle.write(bytearray(b'0')))
        finally:
            handle.close()
    except Exception as ex:
        logger("Carpeta no escribible (%s): %s" % (folder, ex))
        written = False

    xbmcvfs.delete(probe)
    return written


def copy_with_progress(source_path, target_path, message):
    # xbmcvfs.copy() deja Kodi congelado, sin barra y sin poder cancelar. Con un APK
    # de 100 MB no vale, asi que lo copiamos a trozos igual que al descargar
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, message)

    try:
        source = xbmcvfs.File(source_path)
        try:
            total = source.size()
            target = xbmcvfs.File(target_path, 'w')
            try:
                copied = 0
                while True:
                    if dp.iscanceled():
                        raise DownloadCanceled()

                    chunk = source.readBytes(APK_CHUNK_SIZE)
                    if not chunk:
                        break

                    if not target.write(chunk):
                        raise IOError(translate(30072) or "Error al escribir en el disco")

                    copied += len(chunk)

                    if total:
                        dp.update(min(int(copied * 100 / total), 100),
                                  "%s\n%s / %s" % (message, format_size(copied), format_size(total)))
            finally:
                target.close()
        finally:
            source.close()
    finally:
        dp.close()

    written = xbmcvfs.Stat(target_path).st_size()
    if total and written < total:
        raise IOError("Copia incompleta (%s de %s)" % (format_size(written), format_size(total)))

    return written


def stage_apk_public(path):
    # El instalador de Android no ve el sandbox privado de Kodi. Para que el intent
    # funcione, el APK tiene que estar en almacenamiento publico, o sea en /storage/
    if path.startswith('/storage/'):
        return path

    target_dir = next((f for f in APK_FOLDER_CANDIDATES if xbmcvfs.exists(f)), None)
    if not target_dir:
        logger("Sin almacenamiento publico donde preparar el APK", 'error')
        return None

    target = join_path(target_dir, os.path.basename(path))
    if xbmcvfs.exists(target):
        xbmcvfs.delete(target)

    try:
        copy_with_progress(path, target, translate(30066))
    except DownloadCanceled:
        xbmcvfs.delete(target)
        logger("Preparacion del APK cancelada por el usuario")
        return None
    except Exception as ex:
        xbmcvfs.delete(target)
        logger("No se pudo copiar el APK a almacenamiento publico: %s" % ex, 'error')
        xbmcgui.Dialog().ok(HEADING, translate_fmt(30073, os.path.basename(path), ex))
        return None

    logger("APK preparado en almacenamiento publico: %s" % target)
    return target


def try_pm_install(apk_path):
    # Solo tira con root o con Kodi como app de sistema, cosa de algunas cajas Android TV
    attempts = (
        ['pm', 'install', '-r', apk_path],
        ['su', '-c', 'pm install -r "%s"' % apk_path],
    )

    for command in attempts:
        try:
            proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  timeout=PM_INSTALL_TIMEOUT, check=False)
        except Exception as ex:
            logger("pm install (%s) fallo: %s" % (command[0], ex))
            continue

        output = (proc.stdout or b'').decode('utf-8', 'replace').strip()
        logger("pm install (%s): rc=%s %s" % (command[0], proc.returncode, output))

        if proc.returncode == 0 and 'Success' in output:
            return True

    return False


def launch_apk_installer(path):
    uri = 'file://' + urllib_parse.quote(path, safe='/')
    builtin = ('StartAndroidActivity("", "android.intent.action.VIEW", '
               '"application/vnd.android.package-archive", "%s", "1")' % uri)
    logger("Lanzando instalador de Android: %s" % builtin)
    xbmc.executebuiltin(builtin)


def open_unknown_sources_settings():
    xbmc.executebuiltin('StartAndroidActivity("", "android.settings.MANAGE_UNKNOWN_APP_SOURCES")')


def apk_post_download(dest, filename):
    if system_platform != 'android':
        xbmcgui.Dialog().ok(HEADING, translate_fmt(30060, filename, dest))
        return

    autoinstall = apk_autoinstall_supported()

    while True:
        options, actions = list(), list()

        if autoinstall:
            options.append(translate(30061))
            actions.append('install')

        options.append(translate(30062))
        actions.append('manual')
        options.append(translate(30063))
        actions.append('sources')

        if not autoinstall:
            # Sin FileProvider el intent no instala, pero con root o Kodi de sistema
            # aun se puede pasar por pm install
            options.append(translate(30068))
            actions.append('pm_install')

        options.append(translate(30064))
        actions.append('close')

        selected = xbmcgui.Dialog().select(translate(30065), options)
        if selected < 0:
            return

        action = actions[selected]

        if action == 'install':
            staged = stage_apk_public(dest)
            if not staged:
                continue
            launch_apk_installer(staged)
            return

        elif action == 'pm_install':
            staged = stage_apk_public(dest)
            if not staged:
                continue
            if try_pm_install(staged):
                xbmcgui.Dialog().ok(HEADING, translate(30069))
                return
            xbmcgui.Dialog().ok(HEADING, translate(30070))

        elif action == 'manual':
            xbmcgui.Dialog().ok(HEADING, translate_fmt(30055, dest))

        elif action == 'sources':
            open_unknown_sources_settings()
            return

        else:
            return


def download_apk(filename, url):
    # Cada click en el menu arranca el plugin de cero, asi que un Lock de python no
    # serviria de nada y el candado tiene que vivir en una Window property. Sin el,
    # dos clicks seguidos escriben a la vez en el mismo .part y lo corrompen
    window = xbmcgui.Window(10000)
    lock = 'ekhorus_downloading_%s' % filename

    if window.getProperty(lock) == 'true':
        xbmcgui.Dialog().notification(HEADING, translate_fmt(30071, filename), icon_path)
        return

    window.setProperty(lock, 'true')
    try:
        _download_apk(filename, url)
    finally:
        window.clearProperty(lock)


def _download_apk(filename, url):
    folder = xbmcgui.Dialog().browse(3, translate_fmt(30053, filename), 'files', '', False, False,
                                     default_apk_folder())
    if not folder:
        return

    if not folder_is_writable(folder):
        xbmcgui.Dialog().ok(HEADING, translate_fmt(30067, folder))
        return

    set_setting("last_apk_folder", folder)

    dest = join_path(folder, filename)
    partial = dest + '.part'

    if xbmcvfs.exists(dest):
        if apk_looks_valid(dest) is False:
            # Esta corrupto, asi que ni preguntamos ni lo ofrecemos, se rehace y punto
            logger("El APK existente esta corrupto, se descarga de nuevo: %s" % dest, 'error')
            xbmcgui.Dialog().ok(HEADING, translate_fmt(30078, filename))
            xbmcvfs.delete(dest)
        else:
            redownload = xbmcgui.Dialog().yesno(HEADING, translate_fmt(30056, filename),
                                                nolabel=translate(30077), yeslabel=translate(30076))
            if not redownload:
                # El APK ya esta y esta bien, asi que le damos las opciones de instalacion.
                # Lo otro seria dejarle tirado o hacerle bajar otros 100 MB para nada
                apk_post_download(dest, filename)
                return
            xbmcvfs.delete(dest)

    if xbmcvfs.exists(partial):
        xbmcvfs.delete(partial)

    message = translate_fmt(30054, filename)
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, message)

    try:
        download_to(url, partial, dp, message)
    except DownloadCanceled:
        dp.close()
        xbmcvfs.delete(partial)
        logger("Descarga cancelada por el usuario: %s" % filename)
        xbmcgui.Dialog().notification(HEADING, translate(30057), icon_path)
        return
    except Exception as ex:
        dp.close()
        xbmcvfs.delete(partial)
        logger("Error descargando %s: %s" % (filename, ex), 'error')
        xbmcgui.Dialog().ok(HEADING, translate_fmt(30058, filename, ex))
        return

    dp.close()

    # Ultimo filtro antes de darlo por bueno. Si el servidor no mando Content-Length
    # no hemos podido comprobar el tamano, asi que al menos validamos el ZIP
    if apk_looks_valid(partial) is False:
        logger("El APK descargado esta corrupto: %s" % partial, 'error')
        xbmcvfs.delete(partial)
        xbmcgui.Dialog().ok(HEADING, translate_fmt(30079, filename))
        return

    # El nombre final solo se pone si la descarga acabo entera. Asi un APK a medias
    # nunca tiene pinta de instalable
    if not xbmcvfs.rename(partial, dest):
        if not xbmcvfs.copy(partial, dest):
            # Ojo, aqui no vale devolver la ruta del .part. Android no lo reconoce como
            # APK y acabariamos ofreciendo instalar algo que no se puede instalar
            logger("No se pudo dejar el APK como %s" % dest, 'error')
            xbmcvfs.delete(partial)
            xbmcgui.Dialog().ok(HEADING, translate_fmt(30080, filename))
            return
        xbmcvfs.delete(partial)

    logger("APK descargado en %s" % dest)
    apk_post_download(dest, filename)


def downloadFile(url, dest, dp=None):
    import socket
    from urllib.request import urlretrieve

    def _pbhook(numblocks, blocksize, filesize, url=None, dp=None):
        if not dp:
            return

        # dp.update() solo traga int. Ademas, cuando el servidor no manda el tamano,
        # urlretrieve pasa filesize = -1: sin este guardia el porcentaje salia negativo
        # (o clavado al 100% al saltar por la excepcion) durante toda la descarga.
        if filesize > 0:
            percent = int(min(numblocks * blocksize * 100 / filesize, 100))
        else:
            percent = 0

        dp.update(max(0, percent))

    # urlretrieve no acepta timeout: se fija el del socket para que una descarga
    # atascada acabe cortando en vez de dejar el dialogo colgado indefinidamente.
    previo = socket.getdefaulttimeout()
    socket.setdefaulttimeout(HTTP_TIMEOUT * 3)
    try:
        urlretrieve(url, dest, lambda nb, bs, fs, url=url: _pbhook(nb, bs, fs, url, dp))
    finally:
        socket.setdefaulttimeout(previo)

    time.sleep(1)

    return xbmcvfs.Stat(dest).st_size()


def extractFile(source, dest):
    import tarfile
    import zipfile
    ret = True

    if tarfile.is_tarfile(source):
        tar = tarfile.open(source, "r:*")
        tar.extractall(dest)
        tar.close()

    elif zipfile.is_zipfile(source):
        zip = zipfile.ZipFile(source, 'r')
        zip.extractall(dest)
        zip.close()

    else:
        ret = False

    return ret


def install_acestream():
    ruta = ruta_zip = ruta_extract = url = None
    set_setting("install_acestream", '')
    set_setting("acestream_cachefolder", '')

    if not system_platform in ['linux', 'windows']:
        logger("install_acestream: system_platform = %s" % str((system_platform, arquitectura, root)))
        return

    elif system_platform == "windows":
        ruta = translatePath("special://home")
        ruta_zip = os.path.join(ruta, "userdata", "acestream_win.zip")
        ruta_extract = data_path
        url ="https://github.com/Carlesto/Horus/releases/download/ace/acestream_win.zip" # acestream_win

    elif arquitectura == "arm" or (arquitectura == "aarch" and root):
        ruta = translatePath("special://home")
        ruta_zip = os.path.join(ruta, "userdata", "acestream.tar.gz")
        ruta_extract = data_path
        url = "https://github.com/Carlesto/Horus/releases/download/ace/acestream_elec.tar.gz" # linaroNDK

    elif arquitectura == "x86" and root:
        ruta = translatePath("special://home")
        ruta_zip = os.path.join(ruta, "userdata", "acestream.tar.gz")
        ruta_extract = data_path
        url = "https://github.com/Carlesto/Horus/releases/download/ace/acestream_x86.tar.gz" # acestream_x86

    else:
        logger("install_acestream: motor externo system_platform = %s" % str((system_platform, arquitectura, root)))
        set_setting("install_acestream", 'motor externo')
        return


    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, translate(30000))
    logger("Descargando Acestream...")

    try:
        downloadFile(url, ruta_zip, dp)
    except Exception as e:
        logger("Error descargando Acestream: %s" % e, 'error')
        dp.close()
        xbmcgui.Dialog().ok(HEADING, translate(30050))
        return

    dp.update(0, translate(30001))
    logger("Descarga Completa: %s" %ruta_zip)
    time.sleep(1)

    dp.update(33, translate(30002))
    if extractFile(ruta_zip, ruta_extract):
        logger("Archivos descomprimidos en %s" %ruta_extract)
    else:
        dp.update(100, translate(30003) %ruta_extract)
        logger("Error al descomprimir Archivos...")
        if os.path.exists(ruta_zip): os.remove(ruta_zip)
        time.sleep(2)
        dp.close()
        return

    dp.update(90, translate(30004))
    if os.path.exists(ruta_zip): os.remove(ruta_zip)
    logger("Limpiando Archivos...")

    dp.update(100, translate(30005))
    time.sleep(3)
    dp.close()
    if system_platform == "windows":
        set_setting("install_acestream", os.path.join(ruta_extract, 'acestream', 'engine'))
    else:
        set_setting("install_acestream", os.path.join(ruta_extract, 'acestream.engine'))


system_platform, arquitectura, root = get_system_platform()
logger((system_platform, arquitectura, root))
from acestream.server import Server
server = Server(host=get_setting("ip_addr", "127.0.0.1"), port=get_setting("ace_port", 6878))
