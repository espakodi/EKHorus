import json
import re

from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError

# Sin timeout, un motor inalcanzable (ip_addr mal puesta, equipo apagado)
# congela el interfaz de Kodi hasta que el sistema operativo corta la conexion.
DEFAULT_TIMEOUT = 10

# El motor responde json pequeno. Si el host configurado no es un motor y
# devuelve algo enorme, no tiene sentido cargarlo entero en memoria.
MAX_RESPONSE = 4 * 1024 * 1024


def sanitize_host(host):
  """Normaliza lo que el usuario haya tecleado en el ajuste de la IP.

  Es texto libre, asi que llega de todo: esquema en mayusculas, barra final
  al copiar y pegar, espacios, un puerto pegado, o incluso un int (get_setting
  convierte "999" en numero). Sin esto, unos casos reventaban al importar y
  otros dejaban el addon mudo sin explicacion."""
  host = str(host if host is not None else '').strip()
  host = re.sub(r'^https?://', '', host, flags=re.I)   # esquema
  host = host.split('/')[0]                            # ruta sobrante
  host = host.split(':')[0]                            # puerto pegado al host

  return host.strip() or '127.0.0.1'


def version_tuple(value):
  """Compara versiones sin distutils, que desaparece en Python 3.12."""
  parts = list()

  for chunk in re.split(r'[._-]', str(value or '')):
    match = re.match(r'\d+', chunk)
    parts.append(int(match.group()) if match else 0)

  return tuple(parts) if parts else (0,)


class Response(object):

  def __init__(self, data=None, message=None, error=False):
    self.data    = data
    self.error   = error
    self.success = not bool(error)
    self.message = self._parse_message(message)

  def _parse_message(self, message):
    if message:
      # str(): el error puede no ser texto (dict, int...).
      message = str(message).split(']')[-1]
      # .strip() PRIMERO: el motor manda "[x] <no such stream>", y quitar los
      # angulos antes que el espacio dejaba un '<' colgando en el mensaje.
      message = message.strip().lstrip('<').rstrip('>').strip()
      # Si tras el saneado no queda nada ("]", "<>"), message[0] daria IndexError.
      if not message:
        return None

      return '%s%s' % (message[0].upper(), message[1:])


class Request(object):

  def __init__(self, host, port=None, scheme='http', timeout=DEFAULT_TIMEOUT):
    self.base    = self._geturl_base(scheme, host, str(port))
    self.timeout = timeout

  def get(self, req_url, **params):
    apiurl = self._geturl(req_url, **params)
    return self._request(apiurl)

  def _geturl(self, path, **params):
    params = dict(map(self._parse_param, params.items()))
    params = urlencode(params)
    apiurl = str(path).replace(self.base, '').strip('/')

    return '{0}/{1}?{2}'.format(self.base, apiurl, params)

  def _request(self, req_url):
    try:
      with urlopen(req_url, timeout=self.timeout) as connection:
        response = self._parse_json(connection.read(MAX_RESPONSE))
    except (IOError, HTTPError, ValueError) as error:
      response = { 'result': None, 'error': str(error) }
    return self._generate_response(response)

  def _generate_response(self, output):
    result = output.get('result') or output.get('response')
    error  = output.get('error')

    return Response(data=result, error=bool(error), message=error)

  def _geturl_base(self, scheme, host, port):
    # Se compone sin heuristicas. La version anterior solo anadia el puerto
    # "si el host no termina ya en el", asi que con host 10.0.0.80 y puerto 80
    # se lo saltaba y la url apuntaba al puerto equivocado.
    return '{0}://{1}:{2}'.format(scheme or 'http', sanitize_host(host), port)

  def _get_response_key(self, response, key):
    # data solo es un dict si al otro lado hay un motor de verdad. Si el host
    # configurado es otra cosa (un router que responde HTML, una respuesta
    # vacia, un json que no es un objeto), _parse_json deja data a None o a un
    # tipo cualquiera y el .get() lanzaba AttributeError fuera de todo try.
    # Devolver None equivale a "no hay motor aqui", que es la verdad.
    if response.success and isinstance(response.data, dict):
      return response.data.get(key)

  def _parse_json(self, string):
    try:
      data = json.loads(string)
    except (IOError, ValueError):
      return {}

    # El motor siempre responde un objeto. Si llega otra cosa (una lista, un
    # null, un numero), quien la usa hace .get() y reventaria: se trata como
    # respuesta no valida, que es lo que es.
    return data if isinstance(data, dict) else {}

  def _parse_param(self, param):
    key, value = param

    if isinstance(value, bool):
      value = int(value)

    return (key, value)


class Server(Request):
  def __init__(self, host, port=6878, scheme='http', timeout=DEFAULT_TIMEOUT):
    # El puerto sale de un ajuste de texto libre. Se sanea ANTES de construir
    # la url base, para que esta y ping() hablen del mismo puerto: si no, con
    # un puerto invalido ping() decia "motor vivo" y las peticiones fallaban
    # siempre. Ademas, int() sobre basura reventaba el import del addon.
    try:
      self._port = int(port)
      if not 0 < self._port < 65536:
        raise ValueError(port)
    except (TypeError, ValueError):
      self._port = 6878

    self._host = sanitize_host(host)

    Request.__init__(self, self._host, self._port, scheme, timeout)

    self._version = None

  def ping(self, timeout=2):
    """Sondeo barato de conexion TCP, para no bloquear el menu 10 segundos
    cuando el motor esta en una ip remota apagada. No sustituye a available:
    solo dice si el puerto responde."""
    import socket

    try:
      with socket.create_connection((self._host, self._port), timeout=timeout):
        return True
    except Exception:
      return False

  def getservice(self, **params):
    return self.get('webui/api/service', format='json', **params)

  def getversion(self):
    return self.getservice(method='get_version')

  def getserver(self, **params):
    return self.get('server/api', **params)

  def gettoken(self):
    return self.getserver(method='get_api_access_token')

  def getsearch(self, **params):
    return self.getserver(method='search', token=self.token, **params)

  def getstream(self, **params):
    is_hls = params.pop('hls', False)
    apiurl = 'manifest.m3u8' if is_hls else 'getstream'

    version = self.version
    if version and version_tuple(version) < (3, 1, 29):
      params['sid'] = params.pop('pid')

    return self.get('ace/{0}'.format(apiurl), format='json', **params)

  def getbroadcast(self, manifest_url):
    return self.get('hls/manifest.m3u8', format='json', manifest_url=manifest_url)

  def invalidate(self):
    """Olvida la version cacheada. Obligatorio tras parar el motor."""
    self._version = None

  @property
  def version(self):
    # Solo se cachea la respuesta positiva: mientras el motor no responde hay
    # que seguir preguntando (los bucles de arranque esperan a que aparezca).
    if not self._version:
      response = self.getversion()
      self._version = self._get_response_key(response, 'version')

    return self._version

  @property
  def available(self):
    return bool(self.version)

  @property
  def token(self):
    response = self.gettoken()
    return self._get_response_key(response, 'token')
