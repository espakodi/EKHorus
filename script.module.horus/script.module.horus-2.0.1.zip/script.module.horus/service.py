# -*- coding: utf-8 -*-
# EKHorus - The addon's service. With "Guardar todo" off in the History it ends at once.
from lib import playback_watch

playback_watch.vigilar()
